import requests
import threading
import logging
import time

logging.basicConfig( level=logging.DEBUG, format=
'[%(levelname)s] – %(threadName)-10s : %(message)s')

def daemon():
    logging.debug('Lanzado, Leyendo archivo')
    dirFichero = './Requests.txt'
    for i in range(1):
      with open(dirFichero, 'r') as reader:
        for line in reader:
          print(line.rstrip())
      print('-------------------------------------')
      logging.debug('Lanzado, enviando archivo')
      for i in range(1):
        with open(dirFichero, 'rb') as f:
          r = requests.post('https://ServeForms--sfrias.repl.co',
          files={'Requests.txt': f})
          print(r)
    logging.debug('Deteniendo')

d = threading.Thread(target=daemon, name='Rolling')

d.setDaemon(True)

d.start()
