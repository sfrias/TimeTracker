import tornado
import tornado.ioloop
import tornado.web
import os, uuid

class Userform(tornado.web.RequestHandler):
  def get(self):
    self.render("form.html")

class Upload(tornado.web.RequestHandler):
  def post(self):
    fileinfo = self.request.files['filearg'][0]
    print("fileinfo is", fileinfo)
    print()
    fname = fileinfo['filename']
    extn = os.path.splitext(fname)[1]
    cname = str(uuid.uuid4()) + extn
    print(cname)
    fh = open(cname, 'wb')
    fh.write(fileinfo['body'])
    fh.close()
    self.finish(cname + " is uploaded!! Check")
    
application = tornado.web.Application([
  (r"/", Userform), (r"/upload", Upload),
  ], debug=True)

if __name__ == "__main__":
  application.listen(1024)
  tornado.ioloop.IOLoop.instance().start()