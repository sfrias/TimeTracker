import tornado
import tornado.ioloop
import tornado.web
import os, uuid

class Userform(tornado.web.RequestHandler):
  def get(self):
    self.render("reg.html")
    #self.write("Parsing a request")
    task = self.get_argument("mytask","")
    email = self.get_argument("email","")
    hit = self.get_argument("hit","")
    date = self.get_argument("date","")
    time = self.get_argument("time","")
    misite = self.get_argument("misite","")
    progress = self.get_argument("progress","")
    opt = self.get_argument("opt","")
    print(task, email, hit, date, time,
    misite, progress, opt)
    file = open("Requests.txt","a")
    file.write(task+";"+email+";"+hit+";"+
    date+";"+time+";"+misite+";"+progress+
    ";"+opt+"\n")
    file.close()

class Upload(tornado.web.RequestHandler):
  def post(self):
    fileinfo = self.request.files['filearg'][0]
    print("fileinfo is", fileinfo)
    fname = fileinfo['filename']
    extn = os.path.splitext(fname)[1]
    cname = str(uuid.uuid4()) + extn
    fh = open(cname, 'w')
    fh.write(fileinfo['body'])
    self.finish(cname + " is uploaded!! Check...")

application = tornado.web.Application([
  (r"/", Userform), (r"/upload", Upload),],
  debug=True)

if __name__ == "__main__":
  application.listen(8888)
  tornado.ioloop.IOLoop.instance().start()